#!/usr/bin/env python
# coding: utf-8

# In[5]:


import PIL
from PIL import Image
import matplotlib.pyplot as plt
import numpy as np
import os
import pandas as pd


# # 任务1.1

# ### 读取一张图片并用python查看图片，截取图像的有效区域

# In[6]:


img=Image.open('C:\\Users\\86133\\Desktop\\images\\1_1.jpg')#读取图像
plt.imshow(img)#导入内存
plt.show()#查看图像
M,N=img.size
print('图像的像素为：',M,N)#打印图像像素大小
box=[M/2-50,N/2-50,M/2+50,N/2+50]
region=img.crop(box)#截取图像中间中间100行和100列
plt.imshow(region)#查看截取后的图像区域


# # 任务1.2 

# ### 将图片数据划分为RGB三个颜色通道，分别将三个颜色通道的图片数据转换为像素值矩阵

# In[7]:


img_get=img.getpixel((0,0))
print('图像的RGB像素值为：',img_get)#获取图像的RGB像素值
r, g, b = region.split()#划分图像裁剪区域的三个颜色通道
r=np.asarray(r)
g=np.asarray(g)
b=np.asarray(b)
print('r通道的像素矩阵为：','\n',r)#打印r通道的像素矩阵
print('g通道的像素矩阵为：','\n',g)#打印g像素通道的矩阵
print('b通道的像素矩阵为：','\n',b)#打印b像素通道的矩阵


# # 任务1.3

# ### 了解水质图像特征一颜色矩，自定义计算三阶颜色矩的函数

# In[8]:


def var(x=None):
    mid=np.mean(((x-x.mean())**3))
    return np.sign(mid)*abs(mid)**(1/3)#计算三阶矩的函数
var(x=r)#利用自定义的函数计算r通道的三阶矩


# # 任务1.4

# ### 用python分别计算三个颜色通道的一阶颜色矩、二阶颜色矩和三阶颜色矩

# In[9]:


#一阶矩
r_1 = np.mean(r)
g_1 = np.mean(g)
b_1 = np.mean(b)
#二阶矩
r_2=np.std(r)
g_2=np.std(g)
b_2=np.std(b)
#三阶矩
def var(x=None):
    mid=np.mean(((x-x.mean())**3))
    return np.sign(mid)*abs(mid)**(1/3)#计算三阶矩的函数
var(x=r)#利用自定义的函数计算r通道的三阶矩
r_3=var(r)
g_3=var(g)
b_3=var(b)
print(r_1,r_2,r_3,g_1,g_2,g_3,b_1,b_2,b_3)#打印出所有通道的一阶矩、二阶矩、三阶矩


# # 任务1.5

# ### 自定义函数正确获取指定路径中的所有图片名称

# In[10]:


img_shuizhi=os.listdir('C:\\Users\\86133\\Desktop\\images\\')#显示文件夹下所有图像的名字
img_shuizhi


# # 任务1.6

# ### 自定义函数，用循环语句计算所有图片的颜色矩和获取图片标签，分别保存为数组

# In[12]:


label=[]
images=[]
names=os.listdir('C:\\Users\\86133\\Desktop\\images')
for i in range(len(names)):
    M=names[i].split('_')
    label.append(M[0])  
    images.append('C:\\Users\\86133\\Desktop\\images\\'+names[i])
    data=pd.DataFrame(np.zeros((len(images),10)),columns=['类别','R通道一阶矩','G通道一阶矩','B通道一阶矩','R通道二阶矩','G通道二阶矩','B通道二阶矩','R通道三阶矩','G通道三阶矩','B通道三阶矩'])
data.iloc[:,0]=[int(i) for i in label]


# In[ ]:


for l in range(len(images)):
    pic=Image.open(images[l])
    M,N=pic.size
    box=[M/2-50,N/2-50,M/2+50,N/2+50]
    region=pic.crop(box)
    R,G,B=region.split()
    r0=np.array(R)
    g0=np.array(G)
    b0=np.array(B)
    ###一阶矩
    r_1=r0.mean()
    g_1=g0.mean()
    b_1=b0.mean()
    ###二阶矩
    r_2=r0.std()
    g_2=g0.std()
    b_2=b0.std()
    ###三阶矩
    mid_r=np.mean(((r0-r0.mean())**3))
    r_3=np.sign(mid_r)*abs(mid_r)**(1/3)
    mid_g=np.mean(((g0-g0.mean())**3))
    g_3=np.sign(mid_g)*abs(mid_g)**(1/3)
    mid_b=np.mean(((b0-b0.mean())**3))
    b_3=np.sign(mid_b)*abs(mid_b)**(1/3)
    ###标准化数据
    data.iloc[l,1]=r_1/255
    data.iloc[l,2]=g_1/255
    data.iloc[l,3]=b_1/255
    data.iloc[l,4]=r_2/255
    data.iloc[l,5]=g_2/255
    data.iloc[l,6]=b_2/255
    data.iloc[l,7]=r_3/255
    data.iloc[l,8]=g_3/255
    data.iloc[l,9]=b_3/255


# In[14]:


data


# In[15]:


data.to_excel('tu.xls',index = False)#保存


# In[ ]:




