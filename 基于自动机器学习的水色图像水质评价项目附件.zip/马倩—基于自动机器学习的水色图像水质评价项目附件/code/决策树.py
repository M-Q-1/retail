#!/usr/bin/env python
# coding: utf-8

# # 任务2.1

# ### 了解常用的分类算法，选择其中之一作为模型训练，例如决策树

# 常用的分类算法：
# #1.决策树
# #2.K邻近
# #3.朴素贝叶斯
# #4.神经网络
# #5.支持向量机

# # 任务2.2

# ### 导入数据，将数据划分为训练集和测试集，训练模型和预测

# In[3]:


import pandas as pd
data = pd.read_excel('C:\\Users\\86133\\Desktop\\tu.xls', encoding = 'gbk') #读取数据，指定编码为gbk
data


# In[4]:


data = data.as_matrix()


# # 决策树

# In[8]:


#划分训练集和测试集
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(data[:,1:],data[:,0],test_size=0.2)
#导入决策树模型
from sklearn.tree import DecisionTreeClassifier
model1=DecisionTreeClassifier().fit(x_train,y_train)
y_pre=model1.predict(x_test)
from sklearn.metrics import classification_report#评价模型
print(classification_report(y_test,y_pre))
from sklearn.metrics import confusion_matrix#创建混淆矩阵
print(confusion_matrix(y_test,y_pre))
from sklearn.metrics import r2_score#模型拟合评分
print(r2_score(y_test,y_pre))#测试集的准确率


# In[ ]:




