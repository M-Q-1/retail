#!/usr/bin/env python
# coding: utf-8

# ### 导入数据，将数据划分为训练集和测试集，训练模型和预测

# In[4]:


import pandas as pd


# In[5]:


data = pd.read_excel('C:\\Users\\86133\\Desktop\\tu.xls', encoding = 'gbk') #读取数据，指定编码为gbk
data


# In[6]:


data = data.as_matrix()


# # SVM

# ### 直接导入模型

# In[9]:


#划分训练集和测试集
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(data[:,1:],data[:,0],test_size=0.2)
#导入支持向量机模型
from sklearn.svm import SVC#导入函数
model=SVC().fit(x_train,y_train)
y_pre=model.predict(x_test)
y_pre1=model.predict(x_train)
model.score(x_test,y_test)#得到模型在测试集里的预测正确率
#分类模型的评价生成混淆矩阵
from sklearn.metrics import classification_report
a=print(classification_report(y_test,y_pre))
b=print(classification_report(y_train,y_pre1))
from sklearn.metrics import r2_score#模型拟合评分
print(r2_score(y_test,y_pre))#测试集准确率
print(r2_score(y_train,y_pre1))#训练集准确率


# ### 进行调整

# In[10]:


#进行调整
#划分训练集和测试集
from sklearn.model_selection import train_test_split
x_train,x_test,y_train,y_test=train_test_split(data[:,1:]*30,data[:,0],test_size=0.2)
#导入支持向量机模型
from sklearn.svm import SVC#导入函数
model=SVC().fit(x_train,y_train)
y_pre=model.predict(x_test)
y_pre1=model.predict(x_train)
model.score(x_test,y_test)#得到模型在测试集里的预测正确率

#分类模型的评价生成混淆矩阵
from sklearn.metrics import classification_report
c=print(classification_report(y_test,y_pre))
d=print(classification_report(y_train,y_pre1))
print(r2_score(y_test,y_pre))#测试集准确率
print(r2_score(y_train,y_pre1))#训练集准确率
from sklearn import metrics
tra= metrics.confusion_matrix(y_train,y_pre1 )
te= metrics.confusion_matrix(y_test, y_pre)
pd.DataFrame(tra, index = range(1, 6), columns = range(1, 6)).to_excel('train.xls')
pd.DataFrame(te, index = range(1, 6), columns = range(1, 6)).to_excel('te.xls')


# ### 导出

# In[11]:


pd.DataFrame(tra, index = range(1, 6), columns = range(1, 6)).to_excel('train.xls')
pd.DataFrame(te, index = range(1, 6), columns = range(1, 6)).to_excel('te.xls')


# In[ ]:




